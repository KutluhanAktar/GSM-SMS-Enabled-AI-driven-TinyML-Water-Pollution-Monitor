#ifdef INCLUDED_BY_NEUTON_C

/* Model info */
#define NEUTON_MODEL_HEADER_VERSION 1
#define NEUTON_MODEL_QLEVEL 32
#define NEUTON_MODEL_FLOAT_SUPPORT 1
#define NEUTON_MODEL_TASK_TYPE 0  // multiclass classification
#define NEUTON_MODEL_NEURONS_COUNT 6
#define NEUTON_MODEL_WEIGHTS_COUNT 23
#define NEUTON_MODEL_INPUTS_COUNT 4
#define NEUTON_MODEL_INPUT_LIMITS_COUNT 4
#define NEUTON_MODEL_OUTPUTS_COUNT 3
#define NEUTON_MODEL_LOG_SCALE_OUTPUTS 0

/* Preprocessing */
#define NEUTON_PREPROCESSING_ENABLED 0
#define NEUTON_BITMASK_ENABLED 0

/* Limits */
static const float modelInputMin[] = { -293, 0, 0.050000001, 0 };
static const float modelInputMax[] = { 1489, 10.97, 1496.91, 10 };

static const float modelOutputMin[] = { 0, 0, 0 };
static const float modelOutputMax[] = { 1, 1, 1 };

/* Types */
typedef float coeff_t;
typedef float weight_t;
typedef double acc_signed_t;
typedef double acc_unsigned_t;
typedef uint8_t sources_size_t;
typedef uint8_t weights_size_t;
typedef uint8_t neurons_size_t;

/* Structure */
static const weight_t modelWeights[] = {
	0.99644554, -0.79871756, 0.9998095, 0.99990845, -0.32941628, -1, 0.10884696,
	-1, 0, -0.5, 0.5, 1, 0.5, -0.74691439, 0.44428352, -0.5, -1, -1, 1, 0,
	1, -1, 0.3726792 };

static const sources_size_t modelLinks[] = {
	0, 1, 2, 3, 4, 0, 4, 0, 0, 1, 2, 3, 4, 2, 4, 0, 2, 0, 1, 3, 4, 4, 4 };

static const weights_size_t modelIntLinksBoundaries[] = { 0, 6, 8, 14, 17, 22 };
static const weights_size_t modelExtLinksBoundaries[] = { 5, 7, 13, 15, 21, 23 };

static const coeff_t modelFuncCoeffs[] = {
	39.999954, 29.32473, 17.556252, 17.39139, 40, 40 };

static const neurons_size_t modelOutputNeurons[] = { 1, 3, 5 };

#endif // INCLUDED_BY_NEUTON_C

